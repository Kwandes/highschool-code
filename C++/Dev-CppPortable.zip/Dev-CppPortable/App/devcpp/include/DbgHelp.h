#include <imagehlp.h>
