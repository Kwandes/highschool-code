/*
 * This file is part of the Mingw32 package.
 *
 * mem.h maps to string.h
 */
#include <string.h>
