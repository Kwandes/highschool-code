<!--

function Pisz(naz,szer,wys) {
config='left=0,top=0,width='+szer+',height='+wys+',innerheight='+wys+',innerwidth='+szer+',toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no';
NoweOkienko=window.open('','',config);
NoweOkienko.document.open();
NoweOkienko.document.write("<HTML><HEAD><TITLE>Junga</TITLE></HEAD>");
NoweOkienko.document.write("<BODY BGCOLOR='#336699' leftmargin=0 topmargin=250 marginheight=0 marginwidth=0 text=#F5DEB3>");
NoweOkienko.document.write("<p style='font-family: Arial; text-align: center'><B>Czekaj...</B></p><div align=middle style='position: absolute; top: 0px; left: 0px'><A HREF='javascript:window.close()' ><IMG SRC='"+naz+"' alt='kliknij aby zamkn��' BORDER=0></A></DIV></BODY></HTML>");
NoweOkienko.document.close();
NoweOkienko.focus();
}
//-->
